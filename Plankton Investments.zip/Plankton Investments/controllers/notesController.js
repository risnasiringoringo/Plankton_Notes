const NotesModel = require('../models/notesModel');

exports.getAllNotes = async (req, res) => {
  try {
    const [notes] = await NotesModel.getAllNotes();
    res.json(notes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getNoteById = async (req, res) => {
  try {
    const [note] = await NotesModel.getNoteById(req.params.id);
    res.json(note[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.createNote = async (req, res) => {
  try {
    const { title, datetime, note } = req.body;
    await NotesModel.createNote(title, datetime, note);
    res.status(201).json({ message: 'Note created' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.updateNote = async (req, res) => {
  try {
    const { title, datetime, note } = req.body;
    await NotesModel.updateNote(req.params.id, title, datetime, note);
    res.json({ message: 'Note updated' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteNote = async (req, res) => {
  try {
    await NotesModel.deleteNoteById(req.params.id);
    res.json({ message: 'Note deleted' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
