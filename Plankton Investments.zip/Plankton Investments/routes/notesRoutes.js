const express = require('express');
const router = express.Router();
const { createNote, getAllNotes, getNoteById, updateNote, deleteNote } = require('../controllers/notesController');

// Rute untuk menambah note baru
router.post('/', createNote);

// Rute untuk menampilkan semua notes
router.get('/', getAllNotes);

// Rute untuk menampilkan note berdasarkan ID
router.get('/:id', getNoteById);

// Rute untuk mengubah note berdasarkan ID
router.put('/:id', updateNote);

// Rute untuk menghapus note berdasarkan ID
router.delete('/:id', deleteNote);

module.exports = router;
