const db = require('../db'); // Mengimpor koneksi database

// Fungsi untuk menambah note baru
const createNote = (title, datetime, note, callback) => {
  const query = 'INSERT INTO notes (title, datetime, note) VALUES (?, ?, ?)';
  db.query(query, [title, datetime, note], (err, results) => {
    callback(err, results);
  });
};

// Fungsi untuk mendapatkan semua notes
const getAllNotes = (callback) => {
  const query = 'SELECT * FROM notes';
  db.query(query, (err, results) => {
    callback(err, results);
  });
};

// Fungsi untuk mendapatkan note berdasarkan ID
const getNoteById = (id, callback) => {
  const query = 'SELECT * FROM notes WHERE id = ?';
  db.query(query, [id], (err, results) => {
    callback(err, results);
  });
};

// Fungsi untuk mengubah note berdasarkan ID
const updateNote = (id, title, datetime, note, callback) => {
  const query = 'UPDATE notes SET title = ?, datetime = ?, note = ? WHERE id = ?';
  db.query(query, [title, datetime, note, id], (err, results) => {
    callback(err, results);
  });
};

// Fungsi untuk menghapus note berdasarkan ID
const deleteNote = (id, callback) => {
  const query = 'DELETE FROM notes WHERE id = ?';
  db.query(query, [id], (err, results) => {
    callback(err, results);
  });
};

module.exports = { createNote, getAllNotes, getNoteById, updateNote, deleteNote };
